# SEO & Translation Services for Lotus Website

This directory contains the SEO and translation infrastructure for the Lotus programming language website.

## Structure

```
site/
├── js/
│   ├── seo.js              # SEO Service module
│   ├── translation.js      # Translation Service module
│   └── init.js             # Main initialization script
├── locales/
│   └── translations.json   # Multi-language translation strings
├── sitemap.xml             # XML sitemap for search engines
├── robots.txt              # Crawler directives
└── style.css               # Includes styling for language switcher
```

## Features

### SEO Service (`js/seo.js`)

Comprehensive SEO optimization for the Lotus website:

- **Meta Tags Management**
  - Standard meta tags (description, keywords, author, viewport)
  - Open Graph tags for social media sharing
  - Twitter Card tags for enhanced Twitter sharing
  - Canonical URLs to prevent duplicate content

- **Structured Data (JSON-LD)**
  - Software Application schema
  - Breadcrumb navigation schema
  - Custom page-specific schemas
  - SEO-optimized technical details

- **Site Configuration**
  - Site name, URL, and description
  - Author information
  - Locale settings for international SEO

### Translation Service (`js/translation.js`)

Complete multi-language support with automatic language detection:

- **Language Support**
  - English (en)
  - Spanish (es)
  - French (fr)
  - German (de)
  - Japanese (ja)
  - Chinese Simplified (zh)

- **Features**
  - Automatic browser language detection
  - LocalStorage persistence of user language choice
  - Dynamic language switcher with flag emojis
  - Translation key lookup with dot notation
  - Support for HTML content and plain text

- **Language Switching**
  - Fixed position language switcher in top-right corner
  - Active state indication
  - Smooth transitions
  - Mobile responsive

## Usage

### Basic Integration

Add to your HTML pages:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lotus - Programming Language</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Your content with data-i18n attributes -->
    <h1 data-i18n="header.title">Lotus</h1>
    <p data-i18n="header.subtitle">Modern systems programming language</p>
    
    <!-- Include service scripts -->
    <script src="js/seo.js"></script>
    <script src="js/translation.js"></script>
    <script src="js/init.js"></script>
</body>
</html>
```

### Mark Translatable Content

Use `data-i18n` attribute for text content:

```html
<h2 data-i18n="features.title">Key Features</h2>
<p data-i18n="features.description">Explore our language features</p>
```

Use `data-i18n-html` attribute for HTML content:

```html
<div data-i18n-html="documentation.intro">
    Default HTML content here
</div>
```

### Translation File Structure

The `locales/translations.json` file uses a nested object structure:

```json
{
  "en": {
    "nav": {
      "home": "Home",
      "docs": "Documentation"
    },
    "features": {
      "title": "Key Features",
      "description": "..."
    }
  },
  "es": {
    "nav": {
      "home": "Inicio",
      "docs": "Documentación"
    }
  }
}
```

Access translations with dot notation: `nav.home`, `features.title`, etc.

## SEO Optimization

### Meta Tags

The SEO Service automatically manages:

1. **Standard Meta Tags**
   - `description` - Page description for search results
   - `keywords` - Relevant search keywords
   - `author` - Content author attribution
   - `charset` - UTF-8 encoding declaration
   - `viewport` - Responsive design configuration

2. **Open Graph Tags**
   - `og:title` - Title for social sharing
   - `og:description` - Description for social preview
   - `og:image` - Image for social cards
   - `og:url` - Canonical URL
   - `og:type` - Content type (website, article, etc.)
   - `og:locale` - Content language

3. **Twitter Cards**
   - `twitter:card` - Card type (summary_large_image)
   - `twitter:title` - Tweet title
   - `twitter:description` - Tweet description
   - `twitter:image` - Tweet image
   - `twitter:site` - Twitter handle

### Structured Data (JSON-LD)

Add search engine-compatible structured data:

```javascript
const seoService = new SEOService();
seoService.updateStructuredData({
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Lotus",
    // ... more properties
});
```

### Sitemap

`sitemap.xml` includes:
- All main pages
- Alternate language versions
- Last modified dates
- Change frequency
- Priority levels
- hreflang tags for multi-language support

### Robots.txt

`robots.txt` specifies:
- Allowed and disallowed paths
- Crawl delays
- Sitemap location
- User-agent specific rules

## Browser Language Detection

The Translation Service automatically:

1. Checks localStorage for saved language preference
2. Detects browser language via `navigator.language`
3. Falls back to English if unsupported
4. Allows manual language selection

## Mobile Responsiveness

The language switcher is fully responsive:
- Desktop: Fixed position in top-right
- Mobile: Moves to bottom-left with wrapping

## Accessibility

Includes features for SEO and accessibility:

- Skip-to-main-content links
- Screen reader only content (`.sr-only`)
- Proper heading hierarchy
- Semantic HTML structure
- ARIA-compatible language switching

## Customization

### Add New Language

1. Add language code to `TranslationService.supportedLanguages`:
```javascript
this.supportedLanguages = ['en', 'es', 'fr', 'de', 'ja', 'zh', 'pt'];
```

2. Add language name and flag:
```javascript
getLanguageName(lang) {
    const names = {
        // ... existing
        'pt': 'Português'
    };
    return names[lang] || lang.toUpperCase();
}

getLanguageFlag(lang) {
    const flags = {
        // ... existing
        'pt': '🇵🇹'
    };
    return flags[lang] || '🌐';
}
```

3. Add translations to `locales/translations.json`

### Customize SEO Configuration

Modify `js/init.js` `getPageConfig()` function:

```javascript
const configs = {
    '/custom-page.html': {
        title: 'Custom Page Title',
        description: 'Custom page description',
        path: '/custom-page.html',
        keywords: 'custom, keywords, here',
        structuredData: { /* ... */ }
    }
};
```

## Performance Considerations

- Minimal JavaScript overhead
- Lazy loading of language switcher
- Efficient DOM queries
- Lightweight translation lookup
- Cached structured data

## SEO Best Practices Implemented

✅ Responsive meta tags
✅ Open Graph tags for social sharing
✅ Twitter Card optimization
✅ Structured data (JSON-LD)
✅ Sitemap with hreflang tags
✅ robots.txt configuration
✅ Canonical URL management
✅ Mobile-responsive design
✅ Fast page load optimization
✅ Multi-language support with proper hreflang
✅ Breadcrumb navigation schema
✅ Page-specific structured data

## Testing

Check SEO implementation:

1. **Meta Tags**
   - Open DevTools → head section
   - Verify all meta tags are present
   - Check Open Graph tags for social sharing

2. **Structured Data**
   - Validate JSON-LD at [schema.org/validator](https://validator.schema.org/)
   - Check rich snippets in Google Search Console

3. **Sitemap**
   - Visit `/sitemap.xml`
   - Verify all pages listed
   - Check hreflang tags for language variants

4. **Robots.txt**
   - Visit `/robots.txt`
   - Verify crawl rules
   - Check sitemap declaration

5. **Language Switching**
   - Click language buttons
   - Verify page content translates
   - Check localStorage persistence

## Files Reference

| File | Purpose |
|------|---------|
| `js/seo.js` | SEO Service class and methods |
| `js/translation.js` | Translation Service class and methods |
| `js/init.js` | Page initialization and configuration |
| `locales/translations.json` | Multi-language content strings |
| `sitemap.xml` | SEO sitemap with hreflang tags |
| `robots.txt` | Search engine crawler directives |
| `style.css` | Language switcher and SEO styles |

## Future Enhancements

- [ ] Add more languages (Portuguese, Russian, Arabic, etc.)
- [ ] Implement language-specific SEO optimization
- [ ] Add analytics tracking for language preferences
- [ ] Create admin panel for translation management
- [ ] Add automatic language detection from URL
- [ ] Implement CDN optimization
- [ ] Add performance monitoring
- [ ] Create translation review workflow

